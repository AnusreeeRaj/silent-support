import { useLocalSearchParams } from "expo-router";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";

export default function HiddenScreen() {
  const { sosMessage } = useLocalSearchParams();

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🚨 Emergency Mode Activated</Text>

      <Text style={styles.message}>
        {sosMessage}
      </Text>

      <TouchableOpacity style={styles.sosButton}>
        <Text style={styles.sosText}>SOS SENT</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#111",
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  title: {
    color: "red",
    fontSize: 24,
    marginBottom: 20,
    fontWeight: "bold",
  },
  message: {
    color: "white",
    marginBottom: 30,
    textAlign: "center",
  },
  sosButton: {
    backgroundColor: "red",
    padding: 15,
    borderRadius: 10,
  },
  sosText: {
    color: "white",
    fontWeight: "bold",
  },
});